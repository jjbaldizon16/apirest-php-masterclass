<?php 

class ControladorRutas{

	public function index(){

		include "rutas/rutas.php";

	}

}